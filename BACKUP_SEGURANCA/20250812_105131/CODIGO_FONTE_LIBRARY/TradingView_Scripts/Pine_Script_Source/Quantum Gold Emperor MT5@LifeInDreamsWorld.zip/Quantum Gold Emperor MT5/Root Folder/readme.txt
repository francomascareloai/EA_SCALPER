you need copy patch file in fix folder then copy launcher.exe + api.dll + terminal64.exe + fix folder to your broker location and block mt5 update and exclude from antivirus for crack work.


1- dll automatic blockupdate don't need do anything
2- put EA Monolith.ex5 -> in expert folder for testing
3- work only on mt5 build 4468 and you must run launcher instead termina64.exe!
4-restart terminal when you add new file in fix folder


